/*
This is the starting point for ex4

Ex4 Part1

The model consists of one initiator and one target. Modify the initiator to send a series of 128-bit
(16-byte) burst transactions through the 32-bit (4-byte) socket, where each burst consists of a stream
of 4 x 32-bit words written to the same address. The top byte of each 32-bit word should be disabled.
The address should be aligned, i.e. divisible by 4.

Each burst should be structured as follows:

Byte  0, address = A
Byte  1, address = A+1
Byte  2, address = A+2
Byte  3, (disabled)

Byte  4, address = A
Byte  5, address = A+1
Byte  6, address = A+2
Byte  7, (disabled)

Byte  8, address = A
Byte  9, address = A+1
Byte 10, address = A+2
Byte 11, (disabled)

Byte 12, address = A
Byte 13, address = A+1
Byte 14, address = A+2
Byte 15, (disabled)

This desciption assumes you are running on a little-endian host. Otherwise, the address order
within each word will be reversed.

For the purposes of the exercise, the data can be random or can be set to some pattern that is
easy to recognize for debug (such as the proverbial 0xdeadbeef)

Have the target return a generic payload error response if
- the command is not a write
- the streaming width is not equal to 4
- the address is not aligned with 4-byte word boundaries
- the data length is not a multiple of 4

The target already prints out the address, data, and byte enable for each 32-bit word received.

Test your error responses by sending some bad transactions.


Ex4 Part2

Modify the target to print out the address of the transaction object, whether or not the transaction
has a memory manager, and if it has, the value of the reference count.

Modify the initiator to allocate transactions using the memory manager provided in file
../common/mm.h.  Do not forget that the initiator must call acquire() and release().
Investigate what happens if the initiator does not release the transaction.
*/

#include <iomanip>

#include "systemc"
using namespace sc_core;
using namespace sc_dt;
using namespace std;

#include "tlm.h"
#include "../common/mm.h"

// Initiator module generating generic payload transactions
struct Initiator: sc_module, tlm::tlm_bw_transport_if<>
{
  // TLM-2 socket, defaults to 32-bits wide, base protocol
  tlm::tlm_initiator_socket<> socket;
  
  // Data buffer type set to uint64 to handle 4x32-bit words
  sc_dt::uint64 data[2];

  // Byte enabled needed to disable top byte (most significant byte)
  // of each 32-bit word
  int byte_enable;

  // memory manager
  mm m_mm;

  SC_CTOR(Initiator)
  : socket("socket")  // Construct and name socket
  {
    socket.bind(*this);
    SC_THREAD(thread_process);

    // init data
    data[0] = 0xdeadbeefdeaffeedull;
    data[1] = 0x0bad0bed0fab0fadull;
    // disable most significant byte
    byte_enable = 0x00ffffff;
  }

  void thread_process()
  {
    // TLM-2 generic payload transaction, reused across calls to b_transport
    tlm::tlm_generic_payload* trans;  // this must be a pointer
    sc_time delay = SC_ZERO_TIME;

    // Generate a sequence of write bursts
    for (int addr = 0; addr < 64; addr += 8)
    {
      tlm::tlm_command cmd = tlm::TLM_WRITE_COMMAND;

      // Part 2:
      // get transaction data from mm
      trans = m_mm.allocate();      // get mm pointer
      trans->acquire();             // incriment ref counter

      // setters ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      trans->set_command( cmd );
      trans->set_address( addr );
      trans->set_data_ptr( reinterpret_cast<unsigned char*>(&data) );
      trans->set_data_length( 16 );
      trans->set_streaming_width( 4 );
      trans->set_byte_enable_ptr( reinterpret_cast<unsigned char*>(&byte_enable) );
      trans->set_byte_enable_length( 4 );
      trans->set_dmi_allowed( false );
      trans->set_response_status( tlm::TLM_INCOMPLETE_RESPONSE ); // required

      // inject transaction data into socket ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      socket->b_transport( *trans, delay );                       // blocking

      // check response status and delay ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      if ( trans->is_response_error() )
        SC_REPORT_ERROR("TLM-2", "Response error from b_transport");

      cout << "Completed " << (cmd ? "write" : "read") << ", addr = " << hex << addr
           << " at " << sc_time_stamp() << endl;

      // release transaction (decriment ref counter) ~~~~~~~~~~~~~~~~~~~~~~~~~~
      trans->release();
    }
  }

  // TLM-2 backward non-blocking transport method
  virtual tlm::tlm_sync_enum nb_transport_bw( tlm::tlm_generic_payload& trans,
                                              tlm::tlm_phase& phase, sc_time& delay )
  {
    // Dummy method
    return tlm::TLM_ACCEPTED;
  }

  // TLM-2 backward DMI method
  virtual void invalidate_direct_mem_ptr(sc_dt::uint64 start_range,
                                         sc_dt::uint64 end_range)
  {
    // Dummy method
  }
};


// Target module representing a simple memory
struct Target: sc_module, tlm::tlm_fw_transport_if<>
{
  // TLM-2 socket, defaults to 32-bits wide, base protocol
  tlm::tlm_target_socket<> socket;

  SC_CTOR(Target)
  : socket("socket")
  {
    socket.bind(*this);
  }

  // TLM-2 blocking transport method
  virtual void b_transport( tlm::tlm_generic_payload& trans, sc_time& delay )
  {
    tlm::tlm_command cmd = trans.get_command();
    sc_dt::uint64    adr = trans.get_address();
    unsigned char*   ptr = trans.get_data_ptr();
    unsigned int     len = trans.get_data_length();
    unsigned char*   byt = trans.get_byte_enable_ptr();
    unsigned int     bel = trans.get_byte_enable_length();
    unsigned int     wid = trans.get_streaming_width();

    // check the transaction object is only using supported operations
    if (cmd != tlm::TLM_WRITE_COMMAND) {
      trans.set_response_status( tlm::TLM_COMMAND_ERROR_RESPONSE );
      return;
    }
    if (adr % 4 != 0) {
      trans.set_response_status( tlm::TLM_ADDRESS_ERROR_RESPONSE );
      return;
    }
    if (len % 4 != 0) {
      trans.set_response_status( tlm::TLM_BURST_ERROR_RESPONSE );
      return;
    }
    if (wid != 4) {
      trans.set_response_status( tlm::TLM_BURST_ERROR_RESPONSE );
      return;
    }

    if (trans.has_mm())
      cout << "Transaction has a memory manager, address = " << &trans
           << ", ref_count = " << trans.get_ref_count() << "\n";
    else
      cout << "Transaction has no memory manager, address = " << &trans << "\n";


    if ( cmd == tlm::TLM_WRITE_COMMAND )
    {
      for (int i = 0; i < int(len); i += 4)
      {
        cout << "addr = " << adr << ", data = ";
        for (int j = 3; j >= 0; j--)
          cout << hex << setw(2) << setfill('0') << int(ptr[i+j]);
        cout << ", byte enables = ";
        if (bel)
          for (int j = 3; j >= 0; j--)
            cout << hex << setw(2) << setfill('0') << int(byt[(i+j) % bel]);
        else
          cout << "00000000";
        cout << "\n";
      }
    }

    trans.set_response_status( tlm::TLM_OK_RESPONSE );

    // debug assertions
    assert (cmd == tlm::TLM_WRITE_COMMAND);
    assert (adr % 4 == 0);
    assert (len == 16);
    assert (wid == 4);
    assert ((bel == 4) || (bel == 8) || (bel == 12) || (bel == 16));
    for (unsigned int i = 0; i < bel; i++)
      if ((i % 4) == 3)
        assert (byt[i] == 0x00);
      else
        assert (byt[i] == 0xff);
  }

  // TLM-2 forward non-blocking transport method
  virtual tlm::tlm_sync_enum nb_transport_fw( tlm::tlm_generic_payload& trans,
                                              tlm::tlm_phase& phase, sc_time& delay )
  {
    // Dummy method (not TLM-2.0 compliant)
    return tlm::TLM_ACCEPTED;
  }

  // TLM-2 forward DMI method
  virtual bool get_direct_mem_ptr(tlm::tlm_generic_payload& trans,
                                  tlm::tlm_dmi& dmi_data)
  {
    // Dummy method
    return false;
  }

  // TLM-2 debug transport method
  virtual unsigned int transport_dbg(tlm::tlm_generic_payload& trans)
  {
    // Dummy method
    return 0;
  }
};

SC_MODULE(Top)
{
  Initiator *initiator;
  Target    *target;

  SC_CTOR(Top)
  {
    // Instantiate components
    initiator = new Initiator("initiator");
    target    = new Target   ("target");

    // One initiator is bound directly to one target with no intervening bus

    // Bind initiator socket to target socket
    initiator->socket.bind( target->socket );
  }
};


int sc_main(int argc, char* argv[])
{
  Top top("top");
  sc_start();
  return 0;
}

