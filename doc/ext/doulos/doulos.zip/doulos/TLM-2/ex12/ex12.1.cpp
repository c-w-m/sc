/*

Initiator and target connected using two fifos, one for request and one for response

Ex 12 Part 1

Replace the two tlm_fifos with a single tlm_req_rsp_channel, and replace each
pair of ports with a single port having a tlm_blocking_master_if or tlm_blocking_slave_if
The objective is just to get you familiar with the overall structure of this example and
with the TLM-1 classes


Ex 12 Part 2

Replace the port on the initiator with a port having a tlm_transport_if,
connected directly to an export on the target also with a tlm_transport_if
The two processes in the initiator will need to be merged into a single process and re-written
and the process in the target will need to be replaced by an implementation of the transport method

*/


#include "systemc"
using namespace sc_core;
using namespace std;

#include "tlm.h"

// Enumerations borrowed from TLM-2

enum tlm_command {
    TLM_READ_COMMAND,
    TLM_WRITE_COMMAND,
    TLM_IGNORE_COMMAND
};

enum tlm_response_status {
    TLM_OK_RESPONSE = 1,
    TLM_INCOMPLETE_RESPONSE = 0,
    TLM_GENERIC_ERROR_RESPONSE = -1,
    TLM_ADDRESS_ERROR_RESPONSE = -2,
    TLM_COMMAND_ERROR_RESPONSE = -3,
    TLM_BURST_ERROR_RESPONSE = -4,
    TLM_BYTE_ENABLE_ERROR_RESPONSE = -5
};

// Request and respose transaction structures

struct req_t
{
  sc_dt::uint64        m_address;
  tlm_command          m_command;
  int                  m_data;
};

struct rsp_t
{
  int                  m_data;
  tlm_response_status  m_response_status;
};


struct Initiator: sc_module
{
  sc_port<tlm::tlm_blocking_put_if<req_t> > req_port;
  sc_port<tlm::tlm_blocking_get_if<rsp_t> > rsp_port;

  SC_CTOR(Initiator)
  {
    SC_THREAD(req_process);
    SC_THREAD(rsp_process);
  }

  void req_process()
  {
    // Generate a series of requests
    for (int i = 0; i < 8; i++)
    {
      req_t req;
      req.m_command = rand() % 2 ? TLM_WRITE_COMMAND : TLM_READ_COMMAND;
      req.m_address = i;
      req.m_data    = i;

      if (req.m_command)
        cout << "New write, address = " << i << endl;
      else
        cout << "New read, address = " << i << endl;
      req_port->put(req);
    }
  }

  void rsp_process()
  {
    while (true)
    {
      rsp_t rsp;
      rsp_port->get(rsp);
      if (rsp.m_response_status == TLM_OK_RESPONSE)
        cout << "OK response, data = " << rsp.m_data << endl;
      else
        cout << "ERROR response" << endl;
    }
  }
};


struct Target: sc_module
{
  sc_port<tlm::tlm_blocking_get_if<req_t> > req_port;
  sc_port<tlm::tlm_blocking_put_if<rsp_t> > rsp_port;

  SC_CTOR(Target)
  {
    SC_THREAD(thread_process);
  }

  void thread_process()
  {
    int data = 256;
    while(true)
    {
      req_t req;
      rsp_t rsp;
      req_port->get(req);

      if (req.m_command == TLM_WRITE_COMMAND)
        cout << "Executing write, address = " << req.m_address << endl;
      else if (req.m_command == TLM_READ_COMMAND)
      {
        cout << "Executing read, address = " << req.m_address << endl;
        rsp.m_data = --data;
      }
      wait(10, SC_NS);

      rsp.m_response_status = TLM_OK_RESPONSE;
      rsp_port->put(rsp);
    }
  }
};


SC_MODULE(Top)
{
  Initiator*            initiator;
  Target*               target;

  tlm::tlm_fifo<req_t>* req_fifo;
  tlm::tlm_fifo<rsp_t>* rsp_fifo;

  SC_CTOR(Top)
  {
    initiator = new Initiator("initiator");
    target    = new Target("target");

    req_fifo  = new tlm::tlm_fifo<req_t>("req_fifo", -1); // Infinite fifos
    rsp_fifo  = new tlm::tlm_fifo<rsp_t>("rsp_fifo", -1);

    initiator->req_port( *req_fifo );
    initiator->rsp_port( *rsp_fifo );

    target   ->req_port( *req_fifo );
    target   ->rsp_port( *rsp_fifo );
  }
};


int sc_main( int argc, char* argv[])
{
    Top top("top");
    sc_start();
    return 0;
}
