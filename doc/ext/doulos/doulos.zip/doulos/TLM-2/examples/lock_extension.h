
// Filename: lock_extension.h

//----------------------------------------------------------------------
//  Copyright (c) 2008 by Doulos Ltd.
//
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
//
//  http://www.apache.org/licenses/LICENSE-2.0
//
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//----------------------------------------------------------------------

// Version 1  09-Sep-2008


#ifndef __LOCK_EXTENSION_H__
#define __LOCK_EXTENSION_H__

#include "tlm.h"

#include "common_header.h"

struct lock_extension: tlm::tlm_extension<lock_extension>
{
  // LOAD-LINK/STORE-CONDITIONAL command extension for atomic memory operations.

  lock_extension() { cmd = LOAD_LINK; }

  virtual tlm_extension_base* clone() const
  {
    lock_extension* ext = new lock_extension;
    ext->cmd = this->cmd;
    return ext;
  }

  virtual void copy_from(tlm_extension_base const &ext)
  {
    cmd = static_cast<lock_extension const &>(ext).cmd;
  }

  enum cmd_t {LOAD_LINK, STORE_CONDITIONAL};
  cmd_t cmd;
};

#endif

