
This is ex1.

Find the TLM-2.0 installation

Look into the readme and releasenotes files

Browse the source code of the header files below the ./include/tlm directory.
The most important files are in ./include/tlm/tlm_h/tlm_trans
Try to find the core interfaces, the sockets, and the generic payload
Also try to find the TLM-1.0 source code, and the TLM-2.0 utilities

Open the file ./include/tlm/tlm_h/tlm_version.h.  This contains some macros defining the version
of the current release, which you can test in your code

Open and browse the User Manual in the ./docs/release directory

Open and browse the Doxygen documentation from the file ./docs/doxygen/html/index.html.
If you are new to Doxygen, a good starting point is to click to Classes -> Class Hierarchy ->
"Go to the graphical class hierarchy"
