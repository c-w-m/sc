
// Test program for TLM-2.0 endianness conversion functions

#include <systemc>
#include "tlm.h"

#include <iomanip>

using namespace sc_core;
using namespace std;

void printt(char* txt, tlm::tlm_generic_payload& trans)
{
  //tlm::tlm_command cmd = trans.get_command();
  sc_dt::uint64    adr = trans.get_address();
  unsigned char*   ptr = trans.get_data_ptr();
  unsigned int     len = trans.get_data_length();
  unsigned char*   byt = trans.get_byte_enable_ptr();
  unsigned int     bel = trans.get_byte_enable_length();
  //unsigned int     wid = trans.get_streaming_width();

  sc_dt::uint64 data;
  data = *reinterpret_cast<int*>(ptr);
  sc_dt::uint64 bedata = 0;

  if (byt) bedata = *reinterpret_cast<int*>(byt);

  cout << txt << "adr=" << dec << adr << " len=" << dec << len << " data[M..LSB]=";

  for (unsigned int i = 0; i < len; i++)
  {
    int b = ptr[len - i - 1];
    cout << setw(2) << setfill('0') << hex << b;
  }

  cout << " bel=" << dec << bel;
  if (byt)
  {
    cout << " byt= ";
    for (unsigned int i = 0; i < bel; i++)
    {
      int b = byt[bel - i - 1];
      cout << setw(2) << setfill('0') << hex << b;
    }
  }
  cout << endl;
}



SC_MODULE(Top)
{
  SC_CTOR(Top) {
    SC_THREAD(thread);
  }

  template<int SIZE> class dt {
    char content[SIZE];
  };

  void thread() {
    tlm::tlm_generic_payload trans;
    sc_time delay;


// ******************************************
// vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv

// MODIFY THE FOLLOWING CONSTANTS (ONLY)

#define GENERIC
//#define WORD
//#define ALIGNED
//#define SINGLE

    const int GP_ADDRESS      = 0;
    const int GP_DATA_LENGTH  = 8;
    const int GP_BE_LENGTH    = 0;
    const int GP_SOCKET_WIDTH = 4;
    const int DATA_WORD_WIDTH = 4;

    sc_dt::uint64 data = 0x00000F0E0D0C0B0AULL;
    sc_dt::uint64 ben  = 0xFFFF00000000FFFFULL;

// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
// ******************************************


    trans.set_command(tlm::TLM_WRITE_COMMAND);
    trans.set_dmi_allowed(false);
    trans.set_response_status( tlm::TLM_INCOMPLETE_RESPONSE );
    trans.set_data_ptr( reinterpret_cast<unsigned char*>( &data ) );
    trans.set_data_length(GP_DATA_LENGTH);
    trans.set_streaming_width(GP_DATA_LENGTH);
    trans.set_byte_enable_ptr( GP_BE_LENGTH ? reinterpret_cast<unsigned char*>( &ben ) : 0);
    trans.set_byte_enable_length(GP_BE_LENGTH);
    trans.set_address(GP_ADDRESS);

    printt("Before ", trans);

    #ifdef GENERIC
        tlm::tlm_to_hostendian_generic<dt<DATA_WORD_WIDTH> >( &trans, GP_SOCKET_WIDTH);
        printt("During ", trans);
        tlm::tlm_from_hostendian_generic<dt<DATA_WORD_WIDTH> >( &trans, GP_SOCKET_WIDTH);
    #endif

    #ifdef WORD
        tlm::tlm_to_hostendian_word<dt<DATA_WORD_WIDTH> >( &trans, GP_SOCKET_WIDTH);
        printt("During ", trans);
        tlm::tlm_from_hostendian_word<dt<DATA_WORD_WIDTH> >( &trans, GP_SOCKET_WIDTH);
    #endif

    #ifdef ALIGNED
        tlm::tlm_to_hostendian_aligned<dt<DATA_WORD_WIDTH> >( &trans, GP_SOCKET_WIDTH);
        printt("During ", trans);
        tlm::tlm_from_hostendian_aligned<dt<DATA_WORD_WIDTH> >( &trans, GP_SOCKET_WIDTH);
    #endif

    #ifdef SINGLE
        tlm::tlm_to_hostendian_single<dt<DATA_WORD_WIDTH> >( &trans, GP_SOCKET_WIDTH);
        printt("During ", trans);
        tlm::tlm_from_hostendian_single<dt<DATA_WORD_WIDTH> >( &trans, GP_SOCKET_WIDTH);
    #endif

    printt("After  ", trans);
  }
};

int sc_main( int argc, char* argv[])
{
    Top top("top");
    sc_start();
    return 0;
}
