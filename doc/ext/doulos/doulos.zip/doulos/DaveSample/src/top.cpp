#define LT_STYLE
#if !defined(LG_STYLE) && !defined(BEH_STYLE) && !defined(RTL_STYLE) && !defined(LT_STYLE) && !defined(AT_STYLE) && !defined(HLS_STYLE) && !defined(MIXED_STYLE)
#error Missing definiton of modeling style: ALG_STYLE BEH_STYLE RTL_STYLE LT_STYLE AT_STYLE HLS_STYLE MIXED_STYLE
#endif

#if   defined(ALG_STYLE)
#include "top_alg.cpp"
typedef top_alg top_module;
#undef ALG_STYLE
#endif

#if   defined(RTL_STYLE)
#include "top_rtl.cpp"
typedef top_rtl top_module;
#undef RTL_STYLE
#endif 

#if   defined(BEH_STYLE)
#include "top_beh.cpp"
typedef top_beh top_module;
#undef BEH_STYLE
#endif

#if   defined(LT_STYLE)
#include "top_lt.cpp"
typedef top_lt top_module;
#undef LT_STYLE
#endif

#if   defined(AT_STYLE)
#include "top_at.cpp"
typedef top_at top_module;
#undef AT_STYLE
#endif

#if   defined(HLS_STYLE)
#include "top_hls.cpp"
typedef top_hls top_module;
#undef HLS_STYLE
#endif

#if   defined(MIXED_STYLE)
#include "top_mixed.cpp"
typedef top_mixed top_module;
#undef MIXED_STYLE
#endif

#if defined(LG_STYLE) || defined(BEH_STYLE) || defined(RTL_STYLE) || defined(LT_STYLE) || defined(AT_STYLE) || defined(HLS_STYLE) || defined(MIXED_STYLE)
#error Multiple modeling styles defined. Choose one only.
#endif
