#include "rand.h"

namespace util {
  // Better rand
  static int state = 1;

  void srand(int seed) {
      state = seed;
  }

  int rand(void) {
      int const a = 1103515245;
      int const c = 12345;
      state = a * state + c;
      return (state >> 16) & 0x7FFF;
  }
}
