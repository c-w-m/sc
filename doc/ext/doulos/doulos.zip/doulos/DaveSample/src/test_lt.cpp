//BEGIN test.cpp (systemc)
// -*- C++ -*- vim600:sw=2:tw=80:fdm=marker:fmr=<<<,>>>
///////////////////////////////////////////////////////////////////////////////
// $Info: Simple LT test implementation $
//
// A simple initiator with a test_thread that issues most of the interesting
// stuff. Convenience methods read() and write() simplify the test creator's
// life by providing all the TLM intricies. This one is purely LT (loosely
// timed).


///////////////////////////////////////////////////////////////////////////////
// $License: Apache 2.0 $
//
// This file is licensed under the Apache License, Version 2.0 (the "License").
// You may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "test_lt.h"
#include "report.h"
#include "rand.h"
#include <iomanip>
using namespace std;
using namespace sc_core;
using namespace tlm;

namespace {
  // Declare string used as message identifier in SC_REPORT_* calls
  static char const* const MSGID = "/Doulos/example/test";
  // Embed file version information into object to help forensics
  static char const* const RCSID = "(@)$Id: test.cpp  1.0 09/02/12 10:00 dcblack $";
  //                                        FILENAME  VER DATE     TIME  USERNAME
}

///////////////////////////////////////////////////////////////////////////////
// Constructor <<
SC_HAS_PROCESS(test_lt);
test_lt::test_lt(sc_module_name instance_name)
: sc_module(instance_name)
, m_loops(1000)
, m_beg_address(0)
, m_end_address(1024)
, socket("socket")
, m_memory_manager(memory_manager::get_memory_manager())
{
  //TODO: -getopts-
  // Initialize quantum keeper
  m_qk.set_global_quantum(sc_time (300, SC_NS));
  m_qk.reset();
  // Register processes
  SC_THREAD(test_thread);
  REPORT_INFO("Constructed " << name());
}//endconstructor

///////////////////////////////////////////////////////////////////////////////
// Destructor <<
test_lt::~test_lt(void) { REPORT_INFO("Destroyed " << name()); }

///////////////////////////////////////////////////////////////////////////////
// Callbacks
void test_lt::before_end_of_elaboration(void) { REPORT_INFO(__func__ << " " << name()); }
void test_lt::end_of_elaboration(void) { REPORT_INFO(__func__ << " " << name()); }
void test_lt::start_of_simulation(void) { REPORT_INFO(__func__ << " " << name()); }
void test_lt::end_of_simulation(void) { REPORT_INFO(__func__ << " " << name()); }

///////////////////////////////////////////////////////////////////////////////
// Processes <<
void test_lt::test_thread(void)  {
  REPORT_INFO("Started " << __func__ << " " << name());
  REPORT_INFO(m_loops << " random writes and reads");
  for (int loop_count=0; loop_count!=m_loops; ++loop_count) {
    // Random address & data
    addr_t address = (m_beg_address + util::rand()%(m_end_address-m_beg_address)) & ~(sizeof(data_t)-1); // constrained to word boundary
    data_t written = util::rand();
    // Write followed by read
    write(address,written);
    data_t result(~written);
    read(address,result);
    if (result == written) {
      REPORT_INFO_VERB
      (  "Matched -" " 0x" << hex << written
      << " @0x" << hex << address
      ,  SC_HIGH
      );
    } else {
      REPORT_ERROR
      (  "Mismatch -"
      << " read=0x" << hex << result
      << " expected=0x" << hex << written
      << " @0x" << hex << address
      );
    }//endif
  }//endfor
  wait(5,SC_NS);
  REPORT_INFO("Done testing");
  sc_stop();
}

///////////////////////////////////////////////////////////////////////////////
// Helper methods
char const * const tlm_error_str(tlm_response_status id)
{
  switch(id) {
    case                TLM_OK_RESPONSE: return "TLM_OK_RESPONSE";
    case        TLM_INCOMPLETE_RESPONSE: return "TLM_INCOMPLETE_RESPONSE";
    case     TLM_GENERIC_ERROR_RESPONSE: return "TLM_GENERIC_ERROR_RESPONSE";
    case     TLM_ADDRESS_ERROR_RESPONSE: return "TLM_ADDRESS_ERROR_RESPONSE";
    case     TLM_COMMAND_ERROR_RESPONSE: return "TLM_COMMAND_ERROR_RESPONSE";
    case       TLM_BURST_ERROR_RESPONSE: return "TLM_BURST_ERROR_RESPONSE";
    case TLM_BYTE_ENABLE_ERROR_RESPONSE: return "TLM_BYTE_ENABLE_ERROR_RESPONSE";
  }
}

void test_lt::write(addr_t addr, data_t data)
{
  tlm_generic_payload* payload_ptr(m_memory_manager->allocate());

  REPORT_INFO_VERB("write(" << addr << ", 0x" << hex << data << ")",SC_HIGH);
  
  // setup payload 
  payload_ptr->acquire();
  payload_ptr->set_response_status(TLM_INCOMPLETE_RESPONSE);
  payload_ptr->set_address(addr);
  payload_ptr->set_data_length(sizeof(data_t));
  payload_ptr->set_streaming_width(sizeof(data_t));// width = data length => no streaming
  payload_ptr->set_data_ptr(reinterpret_cast<unsigned char *>(&data));
  payload_ptr->set_byte_enable_ptr(0);//disable
  payload_ptr->set_write();
  sc_time t_local( m_qk.get_local_time());
  socket->b_transport(*payload_ptr, t_local);
  if (payload_ptr->is_response_error())
    REPORT_WARNING("Received " << tlm_error_str(payload_ptr->get_response_status()));
  payload_ptr->release();
  REPORT_INFO_VERB("*********>write  t_local =" << t_local,SC_DEBUG);
  m_qk.set_and_sync(t_local);
}//end test_lt::write

void test_lt::read(addr_t addr, data_t& data)
{
  tlm_generic_payload* payload_ptr(m_memory_manager->allocate());
  // setup payload
  payload_ptr->acquire();
  payload_ptr->set_address (addr);
  payload_ptr->set_data_length(sizeof(data_t));
  payload_ptr->set_streaming_width(sizeof(data_t));
  payload_ptr->set_data_ptr(reinterpret_cast<unsigned char *>(&data));
  payload_ptr->set_byte_enable_ptr(0);//disable
  payload_ptr->set_read();
  sc_time t_local( m_qk.get_local_time());
  socket->b_transport(*payload_ptr, t_local);
  if (payload_ptr->is_response_error())
    REPORT_WARNING("Received " << tlm_error_str(payload_ptr->get_response_status()));
  payload_ptr->release();
  REPORT_INFO_VERB("*********>read  t_local =" << t_local,SC_DEBUG);
  m_qk.set_and_sync(t_local);
  REPORT_INFO_VERB("read(" << addr << ", 0x" << hex << data << ")",SC_HIGH);
}//end test_lt::read

//EOF
