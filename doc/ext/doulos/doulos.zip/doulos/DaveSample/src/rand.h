#ifndef RAND_H
#define RAND_H

namespace util {
  // Better rand
  void srand(int seed);
  int rand(void);
}

#endif /*RAND_H*/
