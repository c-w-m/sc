//BEGIN address_map.cpp (systemc)
///////////////////////////////////////////////////////////////////////////////
// $Info: Simple memory map mechanism. $

///////////////////////////////////////////////////////////////////////////////
// $License: Apache 2.0 $
//
// This file is licensed under the Apache License, Version 2.0 (the "License").
// You may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "address_map.h"
#include "report.h"
#include <algorithm>
#include <fstream>
#include <sstream>
#include <iomanip>
using namespace std;

namespace {
  static const char* MSGID = "/utility/address_map";
}

Address_map* Address_map::instance = 0;

////////////////////////////////////////////////////////////////////////////////
// Public

Address_map*
Address_map::get_instance
( void
)
{
  if (instance == 0) {
    instance = new Address_map();
  }
  return instance;
}//end Address_map::get_instance

int    
Address_map::new_mapid
( string mapname
)
{
  // Check for duplication
  if (m_name2mapid.count(mapname) == 1) {
    REPORT_ERROR("Duplicate mapname '" << mapname << "' requested!?");
    return DUP_ID;
  }
  // Assert all sizes are the same
  m_mapid = m_name2port.size();
  m_name2port.push_back(name2port_map_t());
  m_port2name.push_back(port2name_map_t());
  m_addr2port.push_back(addr2port_map_t());
  m_port2addr.push_back(port2addr_map_t());
  m_name2mapid[mapname] = m_mapid;
  return m_mapid;
}//end Address_map::new_mapid

int    
Address_map::get_mapid
( string mapname
) const
{
  if (m_name2mapid.count(mapname) == 0) {
    REPORT_ERROR("Missing mapid group '" << mapname << "'");
    return BAD_ID;
  }
  return m_name2mapid.find(mapname)->second;
}//end Address_map::get_mapid

string
Address_map::get_mapname
( int mapid
) const
{
  if (CURRENT_ID == mapid) { mapid = m_mapid; }
  for (name2mapid_map_t::const_iterator p=m_name2mapid.begin();p!=m_name2mapid.end(); ++p)
  {
    if (p->second == mapid) {
      return p->first;
    }
  }
  REPORT_ERROR("Missing mapid group " << mapid);
  return "";
}//end Address_map::get_mapname

void
Address_map::set_portname
( string portname
, int    portindx
, int    mapid
)
{
  if (BAD_ID == mapid) {
    REPORT_FATAL("Did you forget to call new_mapid()?");
  }//endif
  if (CURRENT_ID == mapid) { mapid = m_mapid; }
  if (mapid < 0 or m_name2port.size() <= mapid) {
    REPORT_FATAL("Bad mapid! Did you get this from new_mapid()?");
  }//endif
  if      (portname ==   "-max"      ) { portindx = MAX_ID;  }
  else if (portname ==   "-min"      ) { portindx = MIN_ID;  }
  else if (portname ==   "-self"     ) { portindx = SELF_ID; }
  else if (portname.find("-bad") == 0) { portindx = BAD_ID;  }
  else                                 { portindx = m_name2port[mapid].size(); }
  //REPORT_INFO("DEBUG: set_portname(" << portname << ") => " << portindx);
  m_name2port[mapid].insert(make_pair(portname,portindx));
  m_port2name[mapid].insert(make_pair(portindx,portname));
}//end Address_map::set_portname


int
Address_map::get_portindex
( string addrname
, int    mapid
) const
{
  int result(BAD_ID);
  if (BAD_ID == mapid) {
    REPORT_FATAL("Did you forget to call new_mapid()?");
  }//endif
  if (CURRENT_ID == mapid) { mapid = m_mapid; }
  if (m_name2port[mapid].count(addrname) == 1) {
    result = m_name2port[mapid].find(addrname)->second;
  } else {
    REPORT_ERROR("Missing port named '" << addrname << "'");
  }
  return result;
}//end Address_map::get_portindex

std::size_t
Address_map::get_portcount
( int    mapid
) const
{
  if (BAD_ID == mapid) {
    REPORT_FATAL("Did you forget to call new_mapid()?");
  }//endif
  if (CURRENT_ID == mapid) { mapid = m_mapid; }
  return m_name2port[mapid].size();
}//end Address_map::get_portcount

std::size_t
Address_map::get_namecount
( int    mapid
) const
{
  if (BAD_ID == mapid) {
    REPORT_FATAL("Did you forget to call new_mapid()?");
  }//endif
  if (CURRENT_ID == mapid) { mapid = m_mapid; }
  if (mapid < 0 or m_addr2port.size() <= mapid) {
    REPORT_FATAL("Bad mapid! Did you get this from new_mapid()?");
  }//endif
  return m_addr2port[mapid].size();
}//end get_namecount

void
Address_map::map_memory
( const string& mapfile
, int           mapid
)
{
  REPORT_INFO("Entering map_memory()");
  if (BAD_ID == mapid) {
    REPORT_FATAL("Did you forget to call new_mapid()?");
  }//endif
  if (CURRENT_ID == mapid) { mapid = m_mapid; }
  if (mapid < 0 or m_addr2port.size() <= mapid) {
    REPORT_FATAL("Bad mapid! Did you get this from new_mapid()?");
  }
  // Determine if re-mapping
  if (mapid >= 0 and m_addr2port[mapid].size() != 0) {
    // Erase old mapping
    REPORT_WARNING("Clearing old mappings for mapid " << mapid);
    m_addr2port[mapid].clear();
    m_port2addr[mapid].clear();
  }//endif
  // Open file containing memory map
  ifstream config(mapfile.c_str());
  if (not config) {
    REPORT_FATAL("map_memory() - unable to open file '" << mapfile << "' for reading.");
  } else {
    REPORT_INFO("Reading memory map from '" << mapfile << "'");
  }//endif
  // Parse memory configuration
  const size_t    max_line(256);
  size_t          lno(0);
  char            buffer[max_line];
  string          addrname;
  addr_t          begin_addr(0);
  vector<addr_t>  map_count(1,0);
  do {
    // {:TODO - improve error checking:}
    config >> skipws; //< Skip leading whitespace
    config.getline(buffer,max_line); //< Read a line
    ++lno;
    if (strlen(buffer) == 0) continue;
    if (isalpha(buffer[0]) or '-' == buffer[0]) { // possible valid record
      istringstream lin(buffer);
      lin >> skipws >> addrname;
      if (addrname.length() == 0) {
        REPORT_ERROR
        ( "Bad configuration "
        << "in file " << mapfile 
        << " on line " << lno
        << " - ignored."
        );
        continue;
      }//endif
      if (addrname[addrname.length()-1] == ':') {
        addrname.erase(addrname.length()-1,1);
        if (m_name2mapid.count(addrname) == 0) {
          REPORT_WARNING("Creating new map '" << addrname << "'");
          mapid = new_mapid(addrname);
        } else {
          REPORT_WARNING("Switching to map '" << addrname << "'");
          mapid = get_mapid(addrname);
          while (map_count.size() != mapid+1) {
            map_count.push_back(~0);
          }//endwhile
          if (map_count[mapid] == ~0) {
            map_count[mapid] = 0;
          }//endif
        }//endif
        continue;
      } else {
        bool offset(false);
        // Skip whitespace
        while (isspace(lin.peek())) {
          lin.get();
        }//endwhile
        if (lin.peek() == '-') { // alias
          string existing;
          lin >> existing;
          if (BAD_ID == mapid) {
            REPORT_FATAL("Map not specified!");
          }//endif
          m_name2port[mapid].insert(std::pair<string,int>(string(addrname),get_portindex(existing,mapid)));
          ++map_count[mapid];
          continue;
        }//endif
        if (lin.peek() == '+') {
          lin.get();
          offset = true;
        }//endif
        intmax_t addr(0);
        if (not util::geti(lin, addr)) {
          REPORT_ERROR("Bad configuration line " << lno << " - ignored.");
          continue;
        }//endif
        if (offset) {
          begin_addr += addr;
        } else {
          begin_addr = addr;
        }//endif
        if (BAD_ID == mapid) {
          REPORT_FATAL("Map not specified!");
        }//endif
        if (m_name2port[mapid].count(addrname) == 0) {
          set_portname(addrname, mapid);
        }//endif
        set_portaddress(addrname, begin_addr, mapid);
        ++map_count[mapid];
      }//endif
    }//endif
  } while (not config.eof());
  for (mapid=0; mapid!=map_count.size(); ++mapid) {
    if (map_count[mapid] == 0) {
      REPORT_ERROR("No mappings found in " << mapfile << " for mapid " << mapid);
    } else if (map_count[mapid] > 0) {
      REPORT_INFO(map_count[mapid] << " mappings found in " << mapfile << " for mapid " << mapid);
    } else {
      // don't report maps not touched by this file
    }//endif
  }//endfor
  REPORT_INFO("Exiting map_memory()");
}//end Address_map::map_memory

string
Address_map::map_to_string
( int           mapid
)
{
  if (BAD_ID == mapid) {
    REPORT_FATAL("Did you forget to call new_mapid()?");
  }//endif
  if (CURRENT_ID == mapid) { mapid = m_mapid; }
  ostringstream result;
  for (addr2port_map_t::const_iterator p=m_addr2port[mapid].begin(); p!=m_addr2port[mapid].end(); ++p)
  {
    result
      << setw(10) << p->first
      << " " << m_port2name[mapid].find(p->second)->second
      << "\n"
      ;
  }
  return result.str();
}//end Address_map::map_to_string

void
Address_map::set_portaddress
( string        mapped_name
, const addr_t& begin_addr
, int           mapid
)
{
  if (BAD_ID == mapid) {
    REPORT_FATAL("Did you forget to call new_mapid()?");
  }//endif
  if (CURRENT_ID == mapid) { mapid = m_mapid; }
  if (mapped_name == "-max") {
    if (m_port2addr[mapid].count(MAX_ID) == 0) {
      m_port2addr[mapid].insert(std::pair<addr_t,int>(MAX_ID, begin_addr));
    } else {
      m_port2addr[mapid].find(MAX_ID)->second = begin_addr;
    }//endif
  } else if (mapped_name == "-min") {
    if (m_port2addr[mapid].count(MIN_ID) == 0) {
      m_port2addr[mapid].insert(std::pair<addr_t,int>(MIN_ID, begin_addr));
    } else {
      m_port2addr[mapid].find(MIN_ID)->second = begin_addr;
    }//endif
  } else if (mapped_name == "-bad") {
    //mapped_name += string("-") + util::to_string(portindx);
    m_addr2port[mapid].insert(std::pair<addr_t,int>(addr_t(begin_addr), BAD_ID));
  } else if (mapped_name == "-self") {
    if (m_port2addr[mapid].count(SELF_ID) == 0) {
      m_port2addr[mapid].insert(std::pair<addr_t,int>(SELF_ID, begin_addr));
    } else {
      m_port2addr[mapid].find(SELF_ID)->second = begin_addr;
    }//endif
    if (m_addr2port[mapid].count(begin_addr) == 0) {
      m_addr2port[mapid].insert(std::pair<addr_t,int>(addr_t(begin_addr), SELF_ID));
    } else {
      m_addr2port[mapid].find(begin_addr)->second = SELF_ID;
    }//endif
  } else {
    if (m_name2port[mapid].count(mapped_name) == 1) { // Look up name
      if (m_addr2port[mapid].count(begin_addr) == 1) {
        REPORT_WARNING("Address collision for '" << mapped_name << "' - overwriting.");
      }//endif
      // Save port mapping
      m_addr2port[mapid].insert(make_pair(begin_addr, m_name2port[mapid].find(mapped_name)->second));
      m_port2addr[mapid].insert(make_pair(m_name2port[mapid].find(mapped_name)->second,begin_addr));
      if (m_port2addr[mapid].count(MIN_ID) == 0) {
        m_port2addr[mapid].insert(std::pair<int,addr_t>(MIN_ID, begin_addr));
      } else {
        addr_t min_addr(m_port2addr[mapid].find(MIN_ID)->second);
        if (min_addr > begin_addr) {
          m_port2addr[mapid].find(MIN_ID)->second = begin_addr;
        }//endif
      }//endif
    } else {
      REPORT_WARNING("Memory map entry '" << mapped_name << "' has no corresponding port - ignored.");
    }//endif
  }//endif
}//end Address_map::set_portaddress

struct addr_compare {
  bool operator()
  ( const pair<addr_t,int>& a
  , const pair<addr_t,int>& b
  )
  {
    return a.first<b.first;
  }
};//endstruct addr_compare

int
Address_map::get_portindex
( const addr_t  address
, int           mapid
) const
{
  if (BAD_ID == mapid) {
    REPORT_FATAL("Did you forget to call new_mapid()?");
  }//endif
  if (CURRENT_ID == mapid) { mapid = m_mapid; }
  if (address >= get_maxaddress()) {
    REPORT_ERROR("Address 0x" << hex << address << " exceeds maximum 0x" << hex << get_maxaddress());
    return MAX_ID;
  }//endif
  addr2port_map_t::const_iterator result
    = m_addr2port[mapid].upper_bound(address);
  if (m_addr2port[mapid].empty()) {
    return BAD_ID; // empty map
  }//endif
  if (result == m_addr2port[mapid].end()) {
    return m_addr2port[mapid].find(m_addr2port[mapid].rbegin()->first)->second;
  } else if (result != m_addr2port[mapid].begin()) {
    --result;
    return result->second;
  } else {
    return BAD_ID;
  }//endif
}//end Address_map::get_portindex

addr_t Address_map::get_base_address // obtain the base address for a given name
( std::string        name
, int                mapid
) const
{
  if (BAD_ID == mapid) {
    REPORT_FATAL("Did you forget to call new_mapid()?");
  }//endif
  if (CURRENT_ID == mapid) { mapid = m_mapid; }
  int port_idx(get_portindex(name,mapid));
  addr_t addr(get_portaddress(port_idx,mapid));
  return addr;
}//end Address_map::get_base_address

addr_t
Address_map::get_portaddress
( int    index
, int    mapid
) const
{
  if (BAD_ID == mapid) {
    REPORT_FATAL("Did you forget to call new_mapid()?");
  }//endif
  if (CURRENT_ID == mapid) { mapid = m_mapid; }
  addr_t result(0);
  if (m_port2addr[mapid].count(index) == 1) {
    result = (m_port2addr[mapid].find(index))->second;
  } else {
    REPORT_WARNING("No map for port index " << index << "");
  }//endif
  return result;
}//end Address_map::get_portaddress

addr_t
Address_map::get_minaddress
( int    mapid
) const
{
  addr_t result(0);
  if (m_port2addr[mapid].count(MIN_ID) == 1) {
    result = m_port2addr[mapid].find(MIN_ID)->second;
  }//endif
  return result;
}

addr_t
Address_map::get_maxaddress
( int    mapid
) const
{
  if (CURRENT_ID == mapid) { mapid = m_mapid; }
  addr_t result(~0);
  if (m_port2addr[mapid].count(MAX_ID) == 1) {
    result = m_port2addr[mapid].find(MAX_ID)->second;
  }//endif
  return result;
}

string
Address_map::get_portname
( int    index
, int    mapid
) const
{
  if (BAD_ID == mapid) {
    REPORT_FATAL("Did you forget to call new_mapid()?");
  }//endif
  if (CURRENT_ID == mapid) { mapid = m_mapid; }
  string result("");
  if (m_port2name[mapid].count(index) == 1) {
    result = (m_port2name[mapid].find(index))->second;
  } else {
    REPORT_WARNING("No map for port index " << index << "");
  }//endif
  return result;
}//end Address_map::get_portname

void Address_map::dump_all
( void
) const
{
  SC_REPORT_INFO(MSGID,"DEBUG: dump_all");
  ostringstream mout;
  mout 
    << "+==============================================================================\n"
    << "|Memory Map Dump\n"
    << "|------------------------------------------------------------------------------\n"
    << "|Maps:\n";
  for ( name2mapid_map_t::const_iterator it=m_name2mapid.begin()
      ; it!=m_name2mapid.end()
      ; ++it
      )
  {
    mout
      << "|  " << it->first
      << " => " << it->second 
      << "\n"
      ;
  }//endfor
  for ( name2mapid_map_t::const_iterator mapit=m_name2mapid.begin()
      ; mapit!=m_name2mapid.end()
      ; ++mapit
      )
  {
    string mapname(mapit->first);
    int    mapid(mapit->second);
    mout << "|Ports(" << mapname << "):\n";
    for ( name2port_map_t::const_iterator it=m_name2port[mapid].begin()
        ; it!=m_name2port[mapid].end()
        ; ++it
        )
    {
      mout
        << "|  " << it->first
        << " => " << it->second
        << "\n"
        ;
    }//endfor
    mout << "|Addresses(" << mapname << "):\n";
    for ( addr2port_map_t::const_iterator it=m_addr2port[mapid].begin()
        ; it!=m_addr2port[mapid].end()
        ; ++it
        )
    {
      mout << "|  0x" << setw(8) << setfill('0') << hex << it->first << " => " << dec;
        switch (it->second) {
          case     BAD_ID: mout << "-BAD";    break;
          case     MAX_ID: mout << "-MAX";    break;
          case    SELF_ID: mout << "-SELF";   break;
          default        : mout << it->second; break;
        }//endswitch
      if      (get_minaddress(mapid) >  it->first) mout << " !MIN!";
      else if (get_minaddress(mapid) == it->first) mout << " *MIN*";
      else if (get_maxaddress(mapid) <  it->first) mout << " !MAX!";
      mout << "\n";
    }//endfor
  }//endfor
  mout
    << "+------------------------------------------------------------------------------\n";
  REPORT_INFO("Memory Map Dump\n" << mout.str());
}//end Address_map::dump_all
 
////////////////////////////////////////////////////////////////////////////////
// Private
Address_map::Address_map // Constructor
( void
)
: m_mapid(BAD_ID) //< must be set by user calling new_mapid()
{
}//end Address_map::Address_map

Address_map::Address_map // Copy constructor
( const Address_map& rhs
)
{
  // Not implemented
}//end Address_map::Address_map

Address_map::~Address_map // Destructor
( void
)
{
  delete instance;
}//end Address_map::~Address_map // Destructor

Address_map&
Address_map::operator=
( const Address_map&
)
{
  // Not implemented
  return *this;
}//end Address_map::operator=

#ifdef TEST_ADDRESS_MAP
int sc_main
( int argc
, char* argv[]
)
{
  string pathname("example.txt");
  { // Create a test file
    ofstream fout(pathname.c_str());
    fout
      << "# This is an example\n"
      << "\n"
      << "  ROM    0\n"
      << "  timer0 0xA00000\n"
      << "  RAM    0xB00000\n"
      << "  timer1 0xA00010\n"
      << "test2:\n"
      << "PIC   +00002010\n" // Leading whitespace is optional
      << "  -self  +20\n"
      << "  bus    -self\n"
      << "\n"
      << "\n"
      << "# The end\n"
      << flush;
  }
  Address_map* address_map(Address_map::get_instance());
  address_map->new_mapid("test");
  address_map->set_portname("ROM");
  address_map->set_portname("RAM");
  address_map->set_portname("PIC");
  address_map->set_portname("timer0");
  address_map->set_portname("timer1");
  address_map->map_memory(pathname);
  REPORT_INFO("Memory Map\n" << address_map->map_to_string());
  addr_t table = { 0, 5, 0xA12345, 0xFF };
  for (addr_t* addr_ptr=table; *addr_ptr != 0xFF; ++addr_ptr) {
    REPORT_INFO(*addr_ptr " -> " << address_map->get_portindex(*addr_ptr));
  }
  uintmax_t errors = sc_report_handler::get_count(SC_ERROR)+sc_report_handler::get_count(SC_FATAL);
  if (errors > 0) SC_REPORT_INFO(MSGID,"FAIL: Exiting simulation with one or more errors indicating failure");
  else            SC_REPORT_INFO(MSGID,"PASS: Successfully exiting main simulation without incident");
  return (errors == 0)?0:1;
}//end sc_main
#endif

//EOF
