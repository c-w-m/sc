//BEGIN mem_lt.cpp (systemc)
///////////////////////////////////////////////////////////////////////////////
// $Info: Simple LT memory implementation $

///////////////////////////////////////////////////////////////////////////////
// $License: Apache 2.0 $
//
// This file is licensed under the Apache License, Version 2.0 (the "License").
// You may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "mem_lt.h"
#include "report.h"
using namespace sc_core;

namespace {
  // Declare string used as message identifier in SC_REPORT_* calls
  static char const* const MSGID = "/Doulos/example/mem";
  // Embed file version information into object to help forensics
  static char const* const RCSID = "(@)$Id: mem.cpp  1.0 09/02/12 10:00 dcblack $";
  //                                        FILENAME VER DATE     TIME  USERNAME
}

///////////////////////////////////////////////////////////////////////////////
// Constructor <<
SC_HAS_PROCESS(mem_lt);
mem_lt::mem_lt
( sc_module_name instance_name
, int            mem_depth
, int            bit_width
, sc_time        latency   
, bool           read_only
)
: sc_module(instance_name)
, socket("socket")
, m_mem_depth(mem_depth)
, m_byt_width(bit_width/8)
, m_mem(mem_depth)
, m_latency(latency)
, m_read_only(read_only)
{
  sc_assert(bit_width % 8 == 0 && bit_width > 8);
  // Register methods
  socket.register_b_transport(this,&mem_lt::b_transport);
  // Register processes - NONE
  REPORT_INFO("Constructed " << " " << name());
}//endconstructor

///////////////////////////////////////////////////////////////////////////////
// Destructor <<
mem_lt::~mem_lt(void) { REPORT_INFO("Destroyed " << name()); }

///////////////////////////////////////////////////////////////////////////////
// TLM-2 forward methods
void mem_lt::b_transport(tlm::tlm_generic_payload& trans, sc_time& delay)
{
  tlm::tlm_command command = trans.get_command();
  sc_dt::uint64    address = trans.get_address();
  unsigned char*   data_ptr = trans.get_data_ptr();
  unsigned int     data_length = trans.get_data_length();
  unsigned char*   byte_enables = trans.get_byte_enable_ptr();
  unsigned int     streaming_width = trans.get_streaming_width();

  // Obliged to check address range and check for unsupported features,
  //   i.e. byte enables, streaming, and bursts
  // Can ignore DMI hint and extensions
  // Using the SystemC report handler is an acceptable way of signalling an error

  if (address >= sc_dt::uint64(m_mem_depth) * m_byt_width) {
    // Only 0..(depth x width - 1)
    trans.set_response_status( tlm::TLM_ADDRESS_ERROR_RESPONSE );
    return;
  } else if (address % m_byt_width) {
    // Only allow aligned bit width transfers
    trans.set_response_status( tlm::TLM_ADDRESS_ERROR_RESPONSE );
    return;
  } else if (byte_enables != 0) {
    // No support for byte enables
    trans.set_response_status( tlm::TLM_BYTE_ENABLE_ERROR_RESPONSE );
    return;
  } else if ((data_length % m_byt_width) != 0 || streaming_width < data_length || data_length == 0
      || (address+data_length)/m_byt_width >= m_mem_depth) {
    // Only allow word-multiple transfers within memory size
    trans.set_response_status( tlm::TLM_BURST_ERROR_RESPONSE );
    return;
  }//endif

  // Obliged to implement read and write commands
  if ( command == tlm::TLM_READ_COMMAND ) {
    memcpy(data_ptr, &m_mem[address/m_byt_width], data_length);
  } else if ( command == tlm::TLM_WRITE_COMMAND && ! m_read_only ) {
    memcpy(&m_mem[address/m_byt_width], data_ptr, data_length);
  } else {
    REPORT_WARNING("Attempt to write read-only memory");
    trans.set_response_status( tlm::TLM_GENERIC_ERROR_RESPONSE );
    return;
  }//endif

  // Memory access time
  delay += (m_latency * data_length/m_byt_width);

  // Obliged to set response status to indicate successful completion
  trans.set_response_status( tlm::TLM_OK_RESPONSE );
}//end mem_lt::b_transport

//EOF
