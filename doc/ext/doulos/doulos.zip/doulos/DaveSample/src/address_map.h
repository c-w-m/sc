#ifndef ADDRESS_MAP_H
#define ADDRESS_MAP_H
///////////////////////////////////////////////////////////////////////////////
// $License: Apache 2.0 $
//
// This file is licensed under the Apache License, Version 2.0 (the "License").
// You may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

////////////////////////////////////////////////////////////////////////////////
// DESCRIPTION
// This class implements a address mapping scheme. This is a singleton
// class.
//
// We assume there may be more than one set of things (e.g. ports or sockets)
// to be mapped and introduce the artificial concept of a map identifier
// (mapid). A mapid is a simple unsigned integer to group address mappings.
// This allows you to have more than one mapping (e.g. different multi-ports
// or multi-sockets may have different mapping tables).  For each group that
// you wish to map, you should call the new_mapid() method prior to setting up
// the port names.  You should also have a memory map file per map group (i.e.
// mapid).
//
// Once files are ready, the configuration is setup in two steps. First, the
// connectivity level (contains the component with multi-ports to be mapped),
// must call the set_portname() each time a port is bound with the "logical
// name" of the port binding (e.g. "timer1"). This should occur during
// elaboration.
//
// Second, after the ports have been mapped, the map_memory() method should be
// called to establish the address relationship. This method takes a filename
// as an argument. The file follows the format:
//
//   # Comments start with a hash
//   Mapname: # specify a map (may be new)
//     Logical_name  Start_address
//     Logical_name  +Offset_from_previous # Specify an offset from previous
//
// The logical name must correspond to the portnames specified in the previous
// step. The start address must be an unsigned number up to 32 bits. If
// preceded with "0x", then hexadecimal will be assumed.  You may include
// blank lines and comments. Comments begin with a hash mark (#) or double
// slash (//). Here is an example of a file. Ignore everything outside the
// veritical bars (|):
//
//  example.map________________________________________________________
// 1 |# This is an example memory map file. This line is a comment.    |
// 2 |                                                                 |
// 3 |Bus1:                                                                |
// 4 |  ROM    0                                                       |
// 5 |  timer0 0x400000                                                |
// 6 |  RAM    0x800000                                                |
// 7 |  timer1 0x400010                                                |
// 8 |                                                                 |
// 9 |# RAM    0x400000 # <-This will cause 2 warnings if uncommented. |
//   |_________________________________________________________________|
//
// Notice that alphabetical or numeric order does not matter; however, you
// should not have any duplicate names or addresses in the list. They will
// result in warnings and loss of data. It might be easier to visually
// validate if the addresses are sorted numerically.
// 
// Example code:
#if 0==1
  // Inside constructor of top-level module
  Address_map* address_map(new Address_map::get_instance);
  int mapid = address_map->new_mapid("Bus1"); //< can ignore mapid variable if always using current
  bus->target_port.bind(ram->target_export);      address_map->set_portname("RAM");   
  bus->target_port.bind(rom->target_export);      address_map->set_portname("ROM");   
  bus->target_port.bind(timer[0]->target_export); address_map->set_portname("timer0");
  bus->target_port.bind(timer[1]->target_export); address_map->set_portname("timer1");
  address_map->map_memory("example.map");
  //...
  //
  // Inside bus component thread
  target_port[address_map->get_portindex(the_address)]->METHOD(ARGS);
  //...
#endif
////////////////////////////////////////////////////////////////////////////////
#include "common.h"
#include <map>
#include <string>
#include <vector>

class Address_map
{
public:
  enum { CURRENT_ID = -1, SELF_ID = -2, BAD_ID = -3, NEXT_ID = -4, MAX_ID = -5, MIN_ID = -6, UNKNOWN_ID = -7, DUP_ID = -8 };
  static Address_map* get_instance
       ( void
       );
  int  new_mapid        // Create a named map and return its mapid
       ( std::string   name
       );
  int         get_mapid // Retrieve the mapid for a given map name
       ( std::string   name
       ) const;
  std::string get_mapname // Retrieve the map name for the specified mapid
       ( int           mapid
       ) const;
  void set_portname // Assign a new port index for the given port name and mapid
       ( std::string   portname
       , int           portindx=UNKNOWN_ID
       , int           mapid=CURRENT_ID
       );
  int  get_portindex // Obtain the port index associated with the specified port name and mapid
       ( std::string   name
       , int           mapid=CURRENT_ID
       ) const;
  std::size_t  get_portcount // Obtain the number of ports in the map
       ( int           mapid=CURRENT_ID
       ) const;
  std::size_t get_namecount // Obtain the number of entries in the map
       ( int         mapid
       ) const;
  void map_memory // Reads file into memory map
       ( const std::string& pathname
       , int                mapid=CURRENT_ID
       );
  std::string map_to_string // Return a string representation of the specified map
       ( int                mapid=CURRENT_ID
       );
  void set_portaddress // store a name/address pair in the map
       ( std::string        name
       , const addr_t&      begin_addr
       , int                mapid=CURRENT_ID
       );
  int  get_portindex // decode an address to select a port index
       ( const addr_t       address
       , int                mapid=CURRENT_ID
       ) const;
  addr_t get_base_address // obtain the base address for a given name
       ( std::string        name
       , int                mapid=CURRENT_ID
       ) const;
  addr_t get_portaddress
       ( int                index
       , int                mapid=CURRENT_ID
       ) const;
  addr_t get_minaddress
       ( int                mapid=CURRENT_ID
       ) const;
  addr_t get_maxaddress
       ( int                mapid=CURRENT_ID
       ) const;
  std::string get_portname
       ( int                index
       , int                mapid=CURRENT_ID
       ) const;
  void dump_all
       ( void
       ) const;
 
private:
  Address_map(void); // Constructor
  Address_map(const Address_map&); // Copy constructor
 ~Address_map(void); // Destructor
  Address_map& operator=(const Address_map& rhs); // Disable assignment

protected:
  static Address_map*               instance;     
  typedef std::map<std::string,int> name2mapid_map_t;
  name2mapid_map_t                  m_name2mapid;
  typedef std::map<std::string,int> name2port_map_t;  
  std::vector<name2port_map_t>      m_name2port;  
  typedef std::map<int,std::string> port2name_map_t;  
  std::vector<port2name_map_t>      m_port2name;  
  typedef std::map<addr_t,int>      addr2port_map_t;  
  std::vector<addr2port_map_t>      m_addr2port;  
  typedef std::map<int,addr_t>      port2addr_map_t;  
  std::vector<port2addr_map_t>      m_port2addr;  
  int                               m_mapid;

};

#endif
