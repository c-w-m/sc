#ifndef TEST_LT_H
#define TEST_LT_H
///////////////////////////////////////////////////////////////////////////////
// A simple initiator with a test_thread that issues most of the interesting
// stuff. Convenience methods read() and write() simplify the test creator's
// life by providing all the TLM intricies. This one is purely LT (loosely
// timed).

///////////////////////////////////////////////////////////////////////////////
// $License: Apache 2.0 $
//
// This file is licensed under the Apache License, Version 2.0 (the "License").
// You may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
///////////////////////////////////////////////////////////////////////////////

#include <systemc>
#include "param.h"
#include "memory_manager.h"
#include "tlm_utils/simple_initiator_socket.h"
#include <tlm_utils/tlm_quantumkeeper.h>

struct test_lt
: sc_core::sc_module
{
public:
  // Ports
  tlm_utils::simple_initiator_socket<test_lt> socket;
  // Constructor
  test_lt(sc_core::sc_module_name instance_name);
  // Destructor
  virtual ~test_lt(void);
  // Callbacks
  void before_end_of_elaboration(void);
  void end_of_elaboration(void);
  void start_of_simulation(void);
  void end_of_simulation(void);
  // Processes
  void test_thread(void);
  // Helper methods
  void write(addr_t addr, data_t data);
  void read(addr_t addr, data_t& data);
private:
  // Data
  unsigned int                 m_loops;
  addr_t                       m_beg_address;
  addr_t                       m_end_address;
  memory_manager*              m_memory_manager;
  tlm_utils::tlm_quantumkeeper m_qk;
};

#endif
