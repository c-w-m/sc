#ifndef TOP_H
#define TOP_H

#if !defined(LG_STYLE) && !defined(BEH_STYLE) && !defined(RTL_STYLE) && !defined(LT_STYLE) && !defined(AT_STYLE) && !defined(HLS_STYLE) && !defined(MIXED_STYLE)
#error Missing definiton of modeling style: ALG_STYLE BEH_STYLE RTL_STYLE LT_STYLE AT_STYLE HLS_STYLE MIXED_STYLE
#endif

#if   defined(ALG_STYLE)
#include "top_alg.h"
typedef top_alg top_module;
#undef ALG_STYLE
#endif

#if   defined(RTL_STYLE)
#include "top_rtl.h"
typedef top_rtl top_module;
#undef RTL_STYLE
#endif

#if   defined(BEH_STYLE)
#include "top_beh.h"
typedef top_beh top_module;
#undef BEH_STYLE
#endif

#if   defined(LT_STYLE)
#include "top_lt.h"
typedef top_lt top_module;
#undef LT_STYLE
#endif

#if   defined(AT_STYLE)
#include "top_at.h"
typedef top_at top_module;
#undef AT_STYLE
#endif

#if   defined(HLS_STYLE)
#include "top_hls.h"
typedef top_hls top_module;
#undef HLS_STYLE
#endif

#if   defined(MIXED_STYLE)
#include "top_mixed.h"
typedef top_mixed top_module;
#undef MIXED_STYLE
#endif

#if defined(LG_STYLE) || defined(BEH_STYLE) || defined(RTL_STYLE) || defined(LT_STYLE) || defined(AT_STYLE) || defined(HLS_STYLE) || defined(MIXED_STYLE)
#error Multiple modeling styles defined. Choose one only.
#endif

#endif /*TOP_H*/
