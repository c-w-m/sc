#include "memory_manager.h"

memory_manager* memory_manager::m_memory_manager_ptr(0);

//EOF
