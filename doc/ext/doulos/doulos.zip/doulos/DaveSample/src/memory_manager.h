#ifndef MEMORY_MANAGER_H
#define MEMORY_MANAGER_H
///////////////////////////////////////////////////////////////////////////////
// A memory manager for TLM 2.0 designs. Should probably live in the heap as a
// singleton object.

///////////////////////////////////////////////////////////////////////////////
// $License: Apache 2.0 $
//
// This file is licensed under the Apache License, Version 2.0 (the "License").
// You may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <tlm>

class memory_manager
: public tlm::tlm_mm_interface
{
  typedef tlm::tlm_generic_payload gp_t;

public:
  gp_t* allocate(void);
  gp_t* allocate_n_acquire(void);
  void  free(gp_t* trans);

  static memory_manager* get_memory_manager(void)
  {
    if (0 == m_memory_manager_ptr) {
      m_memory_manager_ptr = new memory_manager();
    }//endif
    return m_memory_manager_ptr;
  }

private:
  static memory_manager* m_memory_manager_ptr;
  memory_manager(void) //< Constructor
  : free_list(0)
  , empties(0)
  {}

  virtual ~memory_manager(void) //< Destructor
  {
    gp_t* data_ptr;

    while (free_list)
    {
      data_ptr = free_list->trans;

      // Delete generic payload and all extensions
      assert(data_ptr);
      delete data_ptr;

      access* orig = free_list;
      free_list = free_list->next;
      delete orig;
    }

    while (empties)
    {
      access* orig = empties;
      empties = empties->next;

      // Delete free list access struct
      delete orig;
    }
  }

private:
  struct access
  {
    gp_t* trans;
    access* next;
    access* prev;
  };

  access* free_list;
  access* empties;
};

inline memory_manager::gp_t* memory_manager::allocate(void)
{
  gp_t* data_ptr;
  if (free_list)
  {
    data_ptr = free_list->trans;
    empties = free_list;
    free_list = free_list->next;
  }
  else
  {
    data_ptr = new gp_t(this);
  }
  return data_ptr;
}

inline memory_manager::gp_t* memory_manager::allocate_n_acquire(void)
{
  memory_manager::gp_t* trans = allocate();
  trans->acquire();
  return trans;
}

inline void memory_manager::free(gp_t* trans)
{
  trans->reset(); // Delete auto extensions
  if (!empties)
  {
    empties = new access;
    empties->next = free_list;
    empties->prev = 0;
    if (free_list)
      free_list->prev = empties;
  }
  free_list = empties;
  free_list->trans = trans;
  empties = free_list->prev;
}
#endif
