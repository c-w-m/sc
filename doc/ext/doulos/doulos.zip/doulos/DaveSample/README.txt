About the files in this tarball (most have internal documentation):

  - INSTALL.txt -- notes on installation
  - README.txt -- this text
  - RELEASE-NOTES.txt -- updates on important new features and/or bug fixes
  - report.h & report.cpp -- contains some convenient macros to allow streaming output style reporting. For example: 
    > REPORT_INFO("Data " << data << " was sent");
  - sc_main.cpp, top.cpp & top.h -- a prototypical top-level main you can use that is more robust than most and illustrates some techniques
  - mem.h & mem.cpp -- illustrates LT (loosely-timed) memory implementation
  - netlist.h & netlist.cpp -- generates a netlist of your design
  - no_clock.h no_clock_if.h, & no_clock.cpp -- a class similar to sc_clock, but
    without the overhead. Read the headers (also see a presentation "Look Ma! No clocks!" on www.nascug.org
  - Makefile.rules & Makefile.macros -- a set of enhanced GNU make (gmake) files
    that provide automatic platform detection and various enhancements. Use:
    > perldoc Makfiles.rules for more information
  - bin/ directory contains some simply helper scripts used by the makefiles

That's all, folks!
