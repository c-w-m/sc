#include "coord.h"

// Part 1 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Coord operator+(const Coord& left, const Coord& right) {
   static Coord rtn;
   rtn.x = left.x + right.x;
   rtn.y = left.y + right.y;
   return rtn;
}

int operator*(const Coord& left, const Coord& right) {
   static int rtn;
   rtn = left.x * right.x + left.y * right.y;
   return rtn;
}

Coord operator*(const Coord& left, const Coord right) {
   Coord rtn;
   rtn.x = left.x * right.x;
   rtn.y = left.y * right.y;
   return rtn;
}

std::ostream& operator<< (std::ostream& os, const Coord& arg) {
   os << "Coordinates(x,y): (" << arg.x <<", " << arg.y << ")";
   return os;
}

// Part 2 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

std::ostream& operator<< (std::ostream& os, const NamedCoord& arg) {
   std::string nm = arg.name + "(";
   os << nm << arg.xy.x << ", " << arg.xy.y << ")";
   return os;
}