// Essential C++ Exercise 6,
// counter_test.cpp - test bench

#include "counter.h"
#include <cassert>
#include <iostream>
using namespace std;

void check(Counter &C, int value, bool overflow, bool checkoverflow)
{
  cout << "Counter " << C.id() <<
    ": count = " << C.read() << " (expected " << value << ")";
  if (checkoverflow)
    cout << boolalpha << " carry = " << C.carry_out() <<
    " (expected " << overflow << noboolalpha << ")";
  cout << endl;
  assert ((C.read() == value));
  if (checkoverflow) assert (C.carry_out() == overflow);
}

int main (int argc, char* argv[])
{
  // create count1 object with intial value=5 and max count=9
  Counter count1(5, 10, "count1");
  check(count1, 5, false, true);

  // reset
  count1.reset();
  check(count1, 0, false, false);

  // count once
  count1.count();
  check(count1, 1, false, true);

  // count upto maximum
  for (int i = 0; i < 8; i++) count1.count();

  // check value
  check(count1, 9, false, true);

  // count once more to check count cycles through 0
  count1.count();
  check(count1, 0, true, true);

  // count once more to check overflow flag is cleared
  count1.count();
  check(count1, 1, false, true);
  return 0;
}
