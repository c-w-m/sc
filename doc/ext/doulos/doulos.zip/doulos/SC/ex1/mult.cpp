#include "mult.h"

void Mult::action()
{
  f = a * b;
}
